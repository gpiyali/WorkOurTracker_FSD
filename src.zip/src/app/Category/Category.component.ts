import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-category',
  templateUrl: './Category.component.html',
  styles: [] 
})
export class CategoryComponent implements OnInit {
 
 
  

  ngOnInit() {
  }

  
}