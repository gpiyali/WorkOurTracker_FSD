import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-startworkout',
  templateUrl: './StartWorkout.component.html',
  styles: [] 
})
export class StartWorkoutComponent implements OnInit {
 
 
 
 constructor(private router: Router) { }

  ngOnInit() {
	  
  }

 cancelStartWorkout()
{
	this.router.navigate(['/viewWorkout']); 
}
}