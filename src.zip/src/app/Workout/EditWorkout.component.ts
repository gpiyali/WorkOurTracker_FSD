import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-editworkout',
  templateUrl: './EditWorkout.component.html',
  styles: [] 
})
export class EditWorkoutComponent implements OnInit {
 
  

  ngOnInit() {
  }

  
}