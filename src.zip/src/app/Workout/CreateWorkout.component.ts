import { Component, OnInit } from '@angular/core';
import { SharedService } from "./../shared.service";


@Component({
  selector: 'app-createworkout',
  templateUrl: './CreateWorkout.component.html',
  styles: [] ,
  providers:[SharedService] 
})
export class CreateWorkoutComponent implements OnInit {
 addWorkoutCbpm: number=0.1 ;
 
 addWorkoutTitle: string = "";
 addWorkoutNote: string = "";
 addWorkoutCategory: string = "";
 
 constructor(private _sharedService: SharedService) {} 
  

  ngOnInit() {
  }
 incrementFunc(){
              var x=this.addWorkoutCbpm;
              this.addWorkoutCbpm=(x*10 + 0.1*10) / 10;  
            }
   decrementFunc(){
              var x=this.addWorkoutCbpm;
              this.addWorkoutCbpm=(x*10 - 0.1*10) / 10; 
            }
  CreateWorkoutFunc() { 
    this._sharedService.AddWorkout(this); 

  }
}

