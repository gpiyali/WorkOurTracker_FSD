import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-createworkout',
  templateUrl: './CreateWorkout.component.html',
  styles: [] 
})
export class CreateWorkoutComponent implements OnInit {
 addWorkoutCbpm: number=0.1 ;
  
  

  ngOnInit() {
  }
 incrementFunc(){
              var x=this.addWorkoutCbpm;
              this.addWorkoutCbpm=(x*10 + 0.1*10) / 10;  
            }
   decrementFunc(){
              var x=this.addWorkoutCbpm;
              this.addWorkoutCbpm=(x*10 - 0.1*10) / 10; 
            }
  CreateWorkoutFunc() {  

  }
}

