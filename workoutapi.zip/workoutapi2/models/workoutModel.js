'use strict';
var mongoose = require('mongoose');
var Schema=mongoose.Schema;

var workoutSchema = new Schema({
    workoutId: mongoose.Schema.Types.ObjectId,
    workoutTitle: String,
    workoutNote: String,
    caloriesBurnPerMin: Number, 
    createdDt: {
        type: Date,
        default: Date.now
	}
}); 

module.exports.workoutSchema = workoutSchema;
