'use strict';
var mongoose = require('mongoose');


var workoutActiveSchema =new mongoose.Schema({        
    workoutActiveId: mongoose.Schema.Types.ObjectId,
	startDateTime: Date,                                     
    endDateTime: Date   
});

module.exports.workoutActiveSchema = workoutActiveSchema;

/*var WorkoutActive = mongoose.model('WorkoutActive', workoutActiveSchema);
module.exports = WorkoutActive;*/