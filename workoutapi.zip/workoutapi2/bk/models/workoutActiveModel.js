'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var workoutActiveSchema =new Schema({        
    workoutActiveId: mongoose.Schema.Types.ObjectId,
	startDateTime: Date,                                     
    endDateTime: Date   
});

module.exports = mongoose.model('WorkoutActive', workoutActiveSchema);