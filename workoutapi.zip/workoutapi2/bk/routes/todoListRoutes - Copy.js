'use strict';

module.exports = function(app) {
  var todoList = require('../controllers/todoListController');

  var jsondata={
	   "user1" : {
		  "name" : "mahesh",
		  "password" : "password1",
		  "profession" : "teacher",
		  "id": 1
	   },
	   "user2" : {
		  "name" : "suresh",
		  "password" : "password2",
		  "profession" : "librarian",
		  "id": 2
	   },
	   "user3" : {
		  "name" : "ramesh",
		  "password" : "password3",
		  "profession" : "clerk",
		  "id": 3
	   }
  };

  app.get("/", function(req, res) {
		res.status(200).send("Welcome to our restful API");
  });
  
  app.get('/workouts', function (req, res) {
	  res.json(jsondata);
  })
	
  // todoList Routes
  app.route('/tasks')
    .get(todoList.list_all_tasks)
    .post(todoList.create_a_task);


  app.route('/tasks/:taskId')
    .get(todoList.read_a_task)
    .put(todoList.update_a_task)
    .delete(todoList.delete_a_task);
};