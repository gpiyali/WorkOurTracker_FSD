module.exports = {
    url: 'mongodb://localhost:3001/workoutDB'
}