'use strict';
var mongoose = require('mongoose'),
models = require("../models/mongooseSchemaRef.js");

var Workout = models.Workout;
var WorkoutCategory = models.WorkoutCategory;
var WorkoutActive = models.WorkoutActive;

console.log("Workout Model"+models.Workout);

exports.list_all_categories = function(req, res) {
  WorkoutCategory.find({}, function(err, workoutCategory) {
    if (err)
      res.send(err);
    res.json(workoutCategory);
  });
};

exports.create_category = function(req, res) {
  var new_category  = new WorkoutCategory(req.body);
  new_category.save(function(err, workoutCategory) {
    if (err)
      res.send(err);
    res.json(workoutCategory);
  });
};

exports.read_a_category = function(req, res) {
  WorkoutCategory.findById(req.params.categoryId, function(err, workoutCategory) {
    if (err)
      res.send(err);
    res.json(workoutCategory);
  });
};

exports.update_a_category = function(req, res) {
  WorkoutCategory.findOneAndUpdate({_id: req.params.categoryId}, req.body, {new: true}, function(err, workoutCategory) {
    if (err)
      res.send(err);
    res.json(workoutCategory);
  });
};

exports.delete_a_category = function(req, res) {
  WorkoutCategory.remove({
    _id: req.params.categoryId
  }, function(err, workoutCategory) {
    if (err)
      res.send(err);
    res.json({ message: 'category successfully deleted' });
  });
};

exports.list_all_workoutActive = function(req, res) {
  WorkoutActive.find({}, function(err, workoutActive) {
    if (err)
      res.send(err);
    res.json(workoutActive);
  });
};

exports.create_workoutActive = function(req, res) {
  var new_WorkoutActive = new WorkoutActive(req.body);
  new_WorkoutActive.save(function(err, workoutActive) {
    if (err)
      res.send(err);
    res.json(workoutActive);
  });
};


exports.read_workoutActive = function(req, res) {
  WorkoutActive.findById(req.params.workoutActiveId, function(err, workoutActive) {
    if (err)
      res.send(err);
    res.json(workoutActive);
  });
};
exports.update_workoutActive = function(req, res) {
  WorkoutActive.findOneAndUpdate({_id: req.params.workoutActiveId}, req.body, {new: true}, function(err, workoutActive) {
    if (err)
      res.send(err);
    res.json(workoutActive);
  });
};

exports.delete_workoutActive = function(req, res) {
  WorkoutActive.remove({
    _id: req.params.workoutActiveId
  }, function(err, workoutActive) {
    if (err)
      res.send(err);
    res.json({ message: 'WorkoutActive successfully deleted' });
  });
};



exports.list_all_workouts = function(req, res) {
  Workouts.find({}, function(err, workouts) {
    if (err)
      res.send(err);
    res.json(workouts);
  });
};

exports.create_workout = function(req, res) {
  var new_workout = new Workouts(req.body);
  new_workout.save(function(err, workouts) {
    if (err)
      res.send(err);
    res.json(workouts);
  });
};


exports.read_a_workout = function(req, res) {
  Workouts.findById(req.params.workoutId, function(err, workouts) {
    if (err)
      res.send(err);
    res.json(workouts);
  });
};


exports.update_a_workout = function(req, res) {
  Workouts.findOneAndUpdate({_id: req.params.workoutId}, req.body, {new: true}, function(err, workouts) {
    if (err)
      res.send(err);
    res.json(workouts);
  });
};


exports.delete_a_workout = function(req, res) {

  Workouts.remove({
    _id: req.params.workoutId
  }, function(err, workouts) {
    if (err)
      res.send(err);
    res.json({ message: 'workouts successfully deleted' });
  });
};